package nextflow.hello.socket



class SocketMessageDispatcher {

    private static SocketManager socketManager

    static void init(String socketPath) {
        if (socketManager == null) {
            socketManager = new SocketManager(socketPath)
        }
    }

    static void send(String message) {
        if (socketManager != null) {
            socketManager.sendAsync(message)
        } else {
            println "[Dispatcher] SocketManager not initialized."
        }
    }

    static void shutdown() {
        socketManager?.shutdown()
    }
}
