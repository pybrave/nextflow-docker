package nextflow.hello.socket

import groovy.json.JsonOutput

import java.net.StandardProtocolFamily
import java.net.UnixDomainSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.SocketChannel
import java.util.concurrent.*
import java.util.concurrent.locks.ReentrantLock

class SocketManager {

    private final String socketPath
    private SocketChannel channel
    private final ReentrantLock connectionLock = new ReentrantLock()
    private final BlockingQueue<String> messageQueue = new LinkedBlockingQueue<>()
    private final long heartbeatIntervalMillis = 5000

    private boolean  terminated
    private Thread spooler;
    private String workflowId

    SocketManager(String socketPath,String workflowId) {
        this.socketPath = socketPath
        this.workflowId=workflowId
//        startSenderLoop()
    }

    void start(){
        spooler = new Thread(() -> sendMessage0());
        spooler.setDaemon(true);
        spooler.setName("send-message");
        spooler.start();
    }

    private void sendMessage0(){
        long lastHeartbeatTime = 0
        while (!terminated){
            long now = System.currentTimeMillis()

            // 发送心跳
            if (now - lastHeartbeatTime >= heartbeatIntervalMillis) {
                lastHeartbeatTime = now
                sendMessage(JsonOutput.toJson([
                        ingress_event:"__heartbeat__",
                        data:[
                                analysis_id:workflowId,
                        ]

                ]))
            }

            def message = messageQueue.poll(500,TimeUnit.MILLISECONDS)
            if (message) {
                sendMessage(message)
            }
        }
    }

    private void sendMessage(String message){
        println("send message: "+message)
        if (channel == null || !channel.isOpen()) {
            println "[SocketManager] Unable to send message, not connected, try to reconnect."
            connect()
            return
        }

        try {
            def buffer = ByteBuffer.wrap((message + "\n").getBytes("UTF-8"))
            channel.write(buffer)
        } catch (Exception e) {
            println "[SocketManager] Send failed: ${e.message}"

        }
    }

//    private void startSenderLoop() {
//        senderPool.submit {
//            while (running) {
//                try {
//                    def message = messageQueue.take()
//                    println("send message: "+message)
//                    sendInternal(message)
//                } catch (InterruptedException e) {
//                    Thread.currentThread().interrupt()
//                    break
//                }
//            }
//        }
//    }
//
//    private void connect() {
//        connectionLock.lock()
//        try {
//            if (channel == null || !channel.isOpen()) {
//                try {
//                    def address = UnixDomainSocketAddress.of(socketPath)
//                    channel = SocketChannel.open(StandardProtocolFamily.UNIX)
//                    channel.connect(address)
//                    println "[SocketManager] Connected to $socketPath"
//                } catch (Exception e) {
//                    println "[SocketManager] Connection failed: ${e.message}"
//                    channel = null
//                }
//            }
//        } finally {
//            connectionLock.unlock()
//        }
//    }

    void connect() {
        connectionLock.lock()
        try {
            if (channel != null && channel.isOpen()) {
                // 已连接，无需重复连接
                return
            }
            int maxRetries = 5       // 最大重试次数（可调整，或设为-1表示无限）
            int retryCount = 0
            long retryDelayMillis = 2000  // 重试间隔 2 秒

            while (!terminated && (maxRetries < 0 || retryCount < maxRetries)) {
                try {
                    def address = UnixDomainSocketAddress.of(socketPath)
                    channel = SocketChannel.open(StandardProtocolFamily.UNIX)
                    channel.connect(address)
                    println "[SocketManager] Connected to $socketPath"
                    return  // 连接成功，退出重试循环
                } catch (Exception e) {
                    println "[SocketManager] Connection attempt #${retryCount + 1} failed: ${e.message}"
                    channel = null
                    retryCount++
                    if (maxRetries >= 0 && retryCount >= maxRetries) {
                        println "[SocketManager] Reached max retries. Giving up connection."
                        break
                    }
                    try {
                        Thread.sleep(retryDelayMillis)
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt()
                        println "[SocketManager] Connect retry interrupted."
                        break
                    }
                }
            }
        } finally {
            connectionLock.unlock()
        }
    }



    void sendAsync(String message) {
        if (!terminated) {
            messageQueue.offer(message)
        }
    }

    void shutdown() {
        terminated =true
        spooler.join()
        try {
            channel?.close()
        } catch (ignored) {}
        channel = null

        println "[SocketManager] Shutdown complete."
    }
}
