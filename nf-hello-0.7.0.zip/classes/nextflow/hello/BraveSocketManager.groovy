/*
 * Copyright 2021, Seqera Labs
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package nextflow.hello

import groovy.transform.CompileStatic
import groovy.util.logging.Slf4j
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.nio.channels.SocketChannel
import java.nio.channels.Channels
import java.nio.file.Path
import java.nio.file.Paths
import java.net.UnixDomainSocketAddress
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.io.IOException
import java.util.concurrent.Executors
import java.util.concurrent.ExecutorService
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Advanced Unix Domain Socket manager for communicating with Brave browser
 * Supports async communication, JSON handling, and connection pooling
 * 
 * @author Your Name
 */
@Slf4j
@CompileStatic
class BraveSocketManager implements AutoCloseable {
    
    private static final String SOCKET_PATH = "/tmp/brave.sock"
    private static final int DEFAULT_TIMEOUT = 5000 // 5 seconds
    private static final int MAX_RETRIES = 3
    
    private SocketChannel socketChannel
    private BufferedReader reader
    private BufferedWriter writer
    private ExecutorService executor
    private AtomicBoolean isRunning
    private ConcurrentHashMap<String, Future<String>> pendingRequests
    private JsonSlurper jsonSlurper
    
    BraveSocketManager() {
        this.executor = Executors.newCachedThreadPool()
        this.isRunning = new AtomicBoolean(false)
        this.pendingRequests = new ConcurrentHashMap<>()
        this.jsonSlurper = new JsonSlurper()
    }
    
    /**
     * Connect to the Brave Unix Domain Socket with retry logic
     */
    boolean connect(int maxRetries = MAX_RETRIES) {
        int attempts = 0
        while (attempts < maxRetries) {
            try {
                Path socketPath = Paths.get(SOCKET_PATH)
                
                // Check if socket file exists
                if (!socketPath.toFile().exists()) {
                    log.warn("Socket file not found: ${SOCKET_PATH}, attempt ${attempts + 1}/${maxRetries}")
                    attempts++
                    if (attempts < maxRetries) {
                        Thread.sleep(1000) // Wait 1 second before retry
                    }
                    continue
                }
                
                // Create Unix Domain Socket address
                UnixDomainSocketAddress address = UnixDomainSocketAddress.of(socketPath)
                
                // Open socket channel
                socketChannel = SocketChannel.open(address)
                
                // Create reader and writer
                reader = new BufferedReader(new InputStreamReader(Channels.newInputStream(socketChannel)))
                writer = new BufferedWriter(new OutputStreamWriter(Channels.newOutputStream(socketChannel)))
                
                isRunning.set(true)
                log.info("Connected to Brave socket: ${SOCKET_PATH}")
                return true
                
            } catch (IOException | InterruptedException e) {
                log.error("Failed to connect to Brave socket (attempt ${attempts + 1}/${maxRetries}): ${e.message}")
                attempts++
                if (attempts < maxRetries) {
                    try {
                        Thread.sleep(1000)
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt()
                        break
                    }
                }
            }
        }
        return false
    }
    
    /**
     * Send a JSON message synchronously
     */
    String sendJsonMessage(Map message, int timeout = DEFAULT_TIMEOUT) throws IOException {
        if (!isConnected()) {
            throw new IOException("Not connected to socket")
        }
        
        String jsonMessage = JsonOutput.toJson(message)
        return sendJsonMessage(jsonMessage, timeout)
    }
    
    /**
     * Send a JSON string synchronously
     */
    String sendJsonMessage(String jsonMessage, int timeout = DEFAULT_TIMEOUT) throws IOException {
        if (!isConnected()) {
            throw new IOException("Not connected to socket")
        }
        
        try {
            // Send message
            writer.write(jsonMessage)
            writer.newLine()
            writer.flush()
            log.debug("Sent JSON message: ${jsonMessage}")
            
            // Receive response with timeout
            String response = receiveMessageWithTimeout(timeout)
            log.debug("Received JSON response: ${response}")
            return response
            
        } catch (IOException e) {
            log.error("Failed to send/receive JSON message: ${e.message}")
            throw e
        }
    }
    
    /**
     * Send a JSON message asynchronously
     */
    Future<String> sendJsonMessageAsync(Map message) {
        if (!isConnected()) {
            throw new IOException("Not connected to socket")
        }
        
        String jsonMessage = JsonOutput.toJson(message)
        return sendJsonMessageAsync(jsonMessage)
    }
    
    /**
     * Send a JSON string asynchronously
     */
    Future<String> sendJsonMessageAsync(String jsonMessage) {
        if (!isConnected()) {
            throw new IOException("Not connected to socket")
        }
        
        return executor.submit({ ->
            try {
                return sendJsonMessage(jsonMessage)
            } catch (IOException e) {
                log.error("Async message failed: ${e.message}")
                throw new RuntimeException(e)
            }
        } as java.util.concurrent.Callable<String>)
    }
    
    /**
     * Send a simple text message
     */
    void sendMessage(String message) throws IOException {
        if (!isConnected()) {
            throw new IOException("Not connected to socket")
        }
        
        try {
            writer.write(message)
            writer.newLine()
            writer.flush()
            log.debug("Sent message: ${message}")
        } catch (IOException e) {
            log.error("Failed to send message: ${e.message}")
            throw e
        }
    }
    
    /**
     * Receive a message with timeout
     */
    String receiveMessageWithTimeout(int timeoutMs) throws IOException {
        if (reader == null) {
            throw new IOException("Not connected to socket")
        }
        
        Future<String> future = executor.submit({ ->
            try {
                return reader.readLine()
            } catch (IOException e) {
                log.error("Failed to receive message: ${e.message}")
                throw e
            }
        } as java.util.concurrent.Callable<String>)
        
        try {
            String message = future.get(timeoutMs, TimeUnit.MILLISECONDS)
            log.debug("Received message: ${message}")
            return message
        } catch (java.util.concurrent.TimeoutException e) {
            future.cancel(true)
            throw new IOException("Timeout waiting for response after ${timeoutMs}ms")
        } catch (Exception e) {
            throw new IOException("Error receiving message: ${e.message}")
        }
    }
    
    /**
     * Receive a message (blocking)
     */
    String receiveMessage() throws IOException {
        if (reader == null) {
            throw new IOException("Not connected to socket")
        }
        
        try {
            String message = reader.readLine()
            log.debug("Received message: ${message}")
            return message
        } catch (IOException e) {
            log.error("Failed to receive message: ${e.message}")
            throw e
        }
    }
    
    /**
     * Parse JSON response
     */
    Map parseJsonResponse(String jsonResponse) {
        try {
            return (Map) jsonSlurper.parseText(jsonResponse)
        } catch (Exception e) {
            log.error("Failed to parse JSON response: ${e.message}")
            return [error: "Invalid JSON response", raw: jsonResponse]
        }
    }
    
    /**
     * Send a ping message
     */
    boolean ping() {
        try {
            Map pingMessage = [action: "ping", timestamp: System.currentTimeMillis()]
            String response = sendJsonMessage(pingMessage)
            Map parsedResponse = parseJsonResponse(response)
            return parsedResponse.status == "ok" || parsedResponse.action == "pong"
        } catch (Exception e) {
            log.error("Ping failed: ${e.message}")
            return false
        }
    }
    
    /**
     * Check if socket is connected
     */
    boolean isConnected() {
        return socketChannel != null && socketChannel.isConnected() && isRunning.get()
    }
    
    /**
     * Get connection status
     */
    Map getConnectionStatus() {
        return [
            connected: isConnected(),
            socketPath: SOCKET_PATH,
            socketExists: Paths.get(SOCKET_PATH).toFile().exists(),
            running: isRunning.get()
        ]
    }
    
    /**
     * Close the socket connection
     */
    @Override
    void close() throws IOException {
        isRunning.set(false)
        
        try {
            if (writer != null) {
                writer.close()
            }
            if (reader != null) {
                reader.close()
            }
            if (socketChannel != null) {
                socketChannel.close()
            }
            if (executor != null) {
                executor.shutdown()
                if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                    executor.shutdownNow()
                }
            }
            log.info("Disconnected from Brave socket")
        } catch (IOException | InterruptedException e) {
            log.error("Error closing socket: ${e.message}")
            if (e instanceof InterruptedException) {
                Thread.currentThread().interrupt()
            }
            throw new IOException("Error closing socket", e)
        }
    }
    
    /**
     * Example usage method
     */
    static void main(String[] args) {
        BraveSocketManager manager = new BraveSocketManager()
        
        try {
            // Connect to socket
            if (!manager.connect()) {
                println "Failed to connect to Brave socket"
                return
            }
            
            // Check connection status
            println "Connection status: ${manager.getConnectionStatus()}"
            
            // Send a ping
            if (manager.ping()) {
                println "Ping successful"
            } else {
                println "Ping failed"
            }
            
            // Send a test JSON message
            Map testMessage = [
                action: "test",
                data: "Hello from Groovy!",
                timestamp: System.currentTimeMillis()
            ]
            
            String response = manager.sendJsonMessage(testMessage)
            println "Response: ${response}"
            
            // Parse JSON response
            Map parsedResponse = manager.parseJsonResponse(response)
            println "Parsed response: ${parsedResponse}"
            
            // Async example
            Future<String> asyncResponse = manager.sendJsonMessageAsync([
                action: "async_test",
                data: "Async message"
            ])
            
            String asyncResult = asyncResponse.get(10, TimeUnit.SECONDS)
            println "Async response: ${asyncResult}"
            
        } catch (Exception e) {
            println "Error: ${e.message}"
            e.printStackTrace()
        } finally {
            manager.close()
        }
    }
} 