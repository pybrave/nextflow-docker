package nextflow.hello;


public class IngressEvent {
    String  ingress_event;
    WorkflowMessage data;

    public String getIngress_event() {
        return ingress_event;
    }

    public void setIngress_event(String ingress_event) {
        this.ingress_event = ingress_event;
    }

    public WorkflowMessage getData() {
        return data;
    }

    public void setData(WorkflowMessage data) {
        this.data = data;
    }
}
