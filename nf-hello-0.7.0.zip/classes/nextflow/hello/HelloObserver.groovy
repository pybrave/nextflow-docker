/*
 * Copyright 2021, Seqera Labs
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
//https://github.com/bioproj/nextflow-proj/blob/master/plugins/nf-tower/src/main/io/seqera/tower/plugin/TowerClient.groovy
package nextflow.hello

import groovy.json.JsonOutput
import groovy.transform.CompileStatic
import groovy.util.logging.Slf4j
import nextflow.Session
import nextflow.hello.socket.SocketManager
import nextflow.trace.TraceObserver
import nextflow.trace.TraceRecord
import nextflow.processor.TaskHandler
import nextflow.util.Threads

import java.nio.file.Path

import static groovy.json.JsonOutput.*

/**
 * Example workflow events observer
 *
 * @author Paolo Di Tommaso <paolo.ditommaso@gmail.com>
 */
@Slf4j
@CompileStatic
class HelloObserver implements TraceObserver {


    protected SocketManager  socketManager ;
    protected Map<String,String> env = System.getenv()
    protected  workflowId;



    HelloObserver(){
        workflowId = env.get("BRAVE_WORKFLOW_ID");
        socketManager = new SocketManager("/tmp/brave.sock",workflowId.toString())

    }

    void sendMessage(String workflowEvent){
        def ingressEvent = new IngressEvent()
        ingressEvent.ingress_event ="nextflow_executor_event"
        def workflowMessage = new WorkflowMessage()
        ingressEvent.data = workflowMessage
        workflowMessage.analysis_id = workflowId;
        workflowMessage.workflow_event = workflowEvent

        String json = JsonOutput.toJson(ingressEvent)
        socketManager.sendAsync(json)
    }

    @Override
    void onFlowCreate(Session session) {

    }

    @Override
    void onFlowBegin() {
        socketManager.connect()
        socketManager.start()

//        this.sender = Threads.start('Tower-thread', this.&sendTasks0)

        sendMessage("on_flow_begin")

//       socketManager.sendAsync(JsonOutput.toJson())
//        println "Okay, let's begin!"
    }


    @Override
    void onProcessComplete(TaskHandler handler, TraceRecord trace) {
        sendMessage("on_process_complete")
//        println "I completed a task! It's name is '${handler.task.name}'"
    }

    @Override
    void onProcessCached(TaskHandler handler, TraceRecord trace) {
        sendMessage("on_process_cached")
//        println "I found a task in the cache! It's name is '${handler.task.name}'"
    }

    @Override
    void onFilePublish(Path destination, Path source) {
        sendMessage("on_file_publish")
//        println "I published a file${source}! It's located at ${destination.toUriString()}"
    }
    
    @Override
    void onFlowError(TaskHandler handler, TraceRecord trace) {
        sendMessage("on_flow_error")
//        println "Uh oh, something went wrong..."
    }

    @Override
    void onFlowComplete() {
        sendMessage("on_flow_complete")
        socketManager.shutdown()
        println 'All done!'
    }


    protected void sendTasks0(dummy) {

    }
}
