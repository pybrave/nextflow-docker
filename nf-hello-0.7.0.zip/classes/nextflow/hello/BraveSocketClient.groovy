/*
 * Copyright 2021, Seqera Labs
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package nextflow.hello

import groovy.transform.CompileStatic
import groovy.util.logging.Slf4j
import java.nio.channels.SocketChannel
import java.nio.channels.Channels
import java.nio.file.Path
import java.nio.file.Paths
import java.net.UnixDomainSocketAddress
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.io.IOException

/**
 * Unix Domain Socket client for communicating with Brave browser
 * 
 * @author Your Name
 */
@Slf4j
@CompileStatic
class BraveSocketClient implements AutoCloseable {
    
    private static final String SOCKET_PATH = "/tmp/brave.sock"
    private SocketChannel socketChannel
    private BufferedReader reader
    private BufferedWriter writer
    
    /**
     * Connect to the Brave Unix Domain Socket
     */
    void connect() throws IOException {
        try {
            Path socketPath = Paths.get(SOCKET_PATH)
            
            // Check if socket file exists
            if (!socketPath.toFile().exists()) {
                throw new IOException("Socket file not found: ${SOCKET_PATH}")
            }
            
            // Create Unix Domain Socket address
            UnixDomainSocketAddress address = UnixDomainSocketAddress.of(socketPath)
            
            // Open socket channel
            socketChannel = SocketChannel.open(address)
            
            // Create reader and writer
            reader = new BufferedReader(new InputStreamReader(Channels.newInputStream(socketChannel)))
            writer = new BufferedWriter(new OutputStreamWriter(Channels.newOutputStream(socketChannel)))
            
            log.info("Connected to Brave socket: ${SOCKET_PATH}")
            
        } catch (IOException e) {
            log.error("Failed to connect to Brave socket: ${e.message}")
            throw e
        }
    }
    
    /**
     * Send a message to Brave
     */
    void sendMessage(String message) throws IOException {
        if (writer == null) {
            throw new IOException("Not connected to socket")
        }
        
        try {
            writer.write(message)
            writer.newLine()
            writer.flush()
            log.debug("Sent message: ${message}")
        } catch (IOException e) {
            log.error("Failed to send message: ${e.message}")
            throw e
        }
    }
    
    /**
     * Receive a message from Brave
     */
    String receiveMessage() throws IOException {
        if (reader == null) {
            throw new IOException("Not connected to socket")
        }
        
        try {
            String message = reader.readLine()
            log.debug("Received message: ${message}")
            return message
        } catch (IOException e) {
            log.error("Failed to receive message: ${e.message}")
            throw e
        }
    }
    
    /**
     * Send a JSON message and receive response
     */
    String sendJsonRequest(String jsonMessage) throws IOException {
        sendMessage(jsonMessage)
        return receiveMessage()
    }
    
    /**
     * Check if socket is connected
     */
    boolean isConnected() {
        return socketChannel != null && socketChannel.isConnected()
    }
    
    /**
     * Close the socket connection
     */
    @Override
    void close() throws IOException {
        try {
            if (writer != null) {
                writer.close()
            }
            if (reader != null) {
                reader.close()
            }
            if (socketChannel != null) {
                socketChannel.close()
            }
            log.info("Disconnected from Brave socket")
        } catch (IOException e) {
            log.error("Error closing socket: ${e.message}")
            throw e
        }
    }
    
    /**
     * Example usage method
     */
    static void main(String[] args) {
        BraveSocketClient client = new BraveSocketClient()
        
        try {
            // Connect to socket
            client.connect()
            
            // Send a test message
            String testMessage = '{"action": "ping", "data": "Hello from Groovy!"}'
            client.sendMessage(testMessage)
            
            // Receive response
            String response = client.receiveMessage()
            println "Response: ${response}"
            
        } catch (IOException e) {
            println "Error: ${e.message}"
        } finally {
            client.close()
        }
    }
} 