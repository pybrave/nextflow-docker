package nextflow.hello;

public class WorkflowMessage {
    String analysis_id;
    String workflow_event;

    public String getAnalysis_id() {
        return analysis_id;
    }

    public void setAnalysis_id(String analysis_id) {
        this.analysis_id = analysis_id;
    }

    public String getWorkflow_event() {
        return workflow_event;
    }

    public void setWorkflow_event(String workflow_event) {
        this.workflow_event = workflow_event;
    }
}
