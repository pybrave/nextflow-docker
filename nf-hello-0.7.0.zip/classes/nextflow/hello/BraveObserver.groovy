/*
 * Copyright 2021, Seqera Labs
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package nextflow.hello

import groovy.transform.CompileStatic
import groovy.util.logging.Slf4j
import nextflow.trace.TraceObserver
import nextflow.trace.TraceRecord
import nextflow.processor.TaskHandler
import java.nio.file.Path

/**
 * Example workflow events observer with Brave socket communication
 *
 * @author Paolo Di Tommaso <paolo.ditommaso@gmail.com>
 */
@Slf4j
@CompileStatic
class BraveObserver implements TraceObserver {

    private BraveSocketManager braveManager
    private boolean braveEnabled = false

    BraveObserver() {
        // Try to initialize Brave socket connection
        try {
            braveManager = new BraveSocketManager()
            if (braveManager.connect()) {
                braveEnabled = true
                log.info("Brave socket connection established")
            } else {
                log.warn("Failed to connect to Brave socket, continuing without Brave integration")
            }
        } catch (Exception e) {
            log.warn("Could not initialize Brave socket: ${e.message}")
        }
    }

   @Override
    void onFlowBegin() {
        println "Okay, let's begin!"
        
        // Send notification to Brave if available
        if (braveEnabled) {
            try {
                braveManager.sendJsonMessageAsync([
                    action: "workflow_start",
                    message: "Nextflow workflow started",
                    timestamp: System.currentTimeMillis()
                ])
            } catch (Exception e) {
                log.warn("Failed to send workflow start notification to Brave: ${e.message}")
            }
        }
    }

    @Override
    void onProcessComplete(TaskHandler handler, TraceRecord trace) {
        println "I completed a task! It's name is '${handler.task.name}'"
        
        // Send task completion notification to Brave if available
        if (braveEnabled) {
            try {
                braveManager.sendJsonMessageAsync([
                    action: "task_complete",
                    taskName: handler.task.name,
                    status: "completed",
                    timestamp: System.currentTimeMillis()
                ])
            } catch (Exception e) {
                log.warn("Failed to send task completion notification to Brave: ${e.message}")
            }
        }
    }

    @Override
    void onProcessCached(TaskHandler handler, TraceRecord trace) {
        println "I found a task in the cache! It's name is '${handler.task.name}'"
        
        // Send cache hit notification to Brave if available
        if (braveEnabled) {
            try {
                braveManager.sendJsonMessageAsync([
                    action: "task_cached",
                    taskName: handler.task.name,
                    status: "cached",
                    timestamp: System.currentTimeMillis()
                ])
            } catch (Exception e) {
                log.warn("Failed to send cache hit notification to Brave: ${e.message}")
            }
        }
    }

    @Override
    void onFilePublish(Path destination, Path source) {
        println "I published a file${source}! It's located at ${destination.toUriString()}"
        
        // Send file publish notification to Brave if available
        if (braveEnabled) {
            try {
                braveManager.sendJsonMessageAsync([
                    action: "file_published",
                    source: source.toString(),
                    destination: destination.toString(),
                    timestamp: System.currentTimeMillis()
                ])
            } catch (Exception e) {
                log.warn("Failed to send file publish notification to Brave: ${e.message}")
            }
        }
    }
    
    @Override
    void onFlowError(TaskHandler handler, TraceRecord trace) {
        println "Uh oh, something went wrong..."
        
        // Send error notification to Brave if available
        if (braveEnabled) {
            try {
                braveManager.sendJsonMessageAsync([
                    action: "workflow_error",
                    taskName: handler?.task?.name ?: "unknown",
                    error: "Workflow error occurred",
                    timestamp: System.currentTimeMillis()
                ])
            } catch (Exception e) {
                log.warn("Failed to send error notification to Brave: ${e.message}")
            }
        }
    }

    @Override
    void onFlowComplete() {
        println 'All done!'
        
        // Send workflow completion notification to Brave if available
        if (braveEnabled) {
            try {
                braveManager.sendJsonMessageAsync([
                    action: "workflow_complete",
                    message: "Nextflow workflow completed successfully",
                    timestamp: System.currentTimeMillis()
                ])
            } catch (Exception e) {
                log.warn("Failed to send workflow completion notification to Brave: ${e.message}")
            }
        }
        
        // Close Brave connection
        try {
            braveManager?.close()
        } catch (Exception e) {
            log.warn("Error closing Brave connection: ${e.message}")
        }
    }
} 